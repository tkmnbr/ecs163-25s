console.log("🚀 main.js loaded");

// 1) データ読み込み
Promise.all([
  d3.csv("data/ds_salaries.csv", d => {
    return {
      work_year:        +d.work_year,
      experience_level: d.experience_level,
      employment_type:  d.employment_type,
      company_size:     d.company_size,
      salary:           +d.salary_in_usd,
      country:          d.employee_residence,
      remote_ratio:     +d.remote_ratio
    };
  }),
  d3.json("data/countries.geojson")
]).then(([salaryData, worldTopo]) => {
  drawMap(salaryData, worldTopo);
  drawSankey(salaryData);
  drawHistogram(salaryData);
});

// 2) 地図（Overview）
function drawMap(data, geo) {
  const svg    = d3.select("#map");
  const width  = svg.node().clientWidth;
  const height = svg.node().clientHeight;

  // (既存) データ集計・GeoJSON変換・プロジェクション設定…
  const avgByCountry = d3.rollup(
    data, v => d3.mean(v, d => d.salary), d => d.country
  );
  const countries = geo.features;
  const projection = d3.geoMercator().fitSize([width, height], geo);
  const path       = d3.geoPath(projection);
  const color = d3.scaleSequential(d3.interpolateYlGnBu)
                  .domain(d3.extent(Array.from(avgByCountry.values())));

  // —————————————— 地図パス描画 ——————————————
  svg.selectAll("path")
    .data(countries)
    .join("path")
      .attr("d", path)
      .attr("fill", d => {
        const iso2 = d.properties["ISO3166-1-Alpha-2"];
        const avg  = avgByCountry.get(iso2);
        return avg != null ? color(avg) : "#eee";
      })
      .attr("stroke", "#999");

  // —————————————— 2) 凡例 ——————————————
  const legendWidth  = 200;
  const legendHeight = 10;
  const legendX      = 20;
  const legendY      = height - 30;

  // グラデーション定義
  const defs = svg.append("defs");
  const lg   = defs.append("linearGradient")
                   .attr("id", "legend-gradient");
  lg.selectAll("stop")
    .data(d3.range(0, 1.01, 0.25))
    .join("stop")
      .attr("offset", d => `${d * 100}%`)
      .attr("stop-color", d => color(
        d3.interpolateNumber(...color.domain())(d)
      ));

  // 凡例バー
  const legendG = svg.append("g")
    .attr("transform", `translate(${legendX},${legendY})`);
  legendG.append("rect")
    .attr("width", legendWidth)
    .attr("height", legendHeight)
    .style("fill", "url(#legend-gradient)")
    .style("stroke", "#999");

  // 凡例軸
  const legendScale = d3.scaleLinear()
    .domain(color.domain())
    .range([0, legendWidth]);
  legendG.append("g")
    .attr("transform", `translate(0,${legendHeight})`)
    .call(d3.axisBottom(legendScale)
      .ticks(5)
      .tickFormat(d3.format("$.2s"))
    );
}






// 3) サンキー図（Focus）
function drawSankey(data) {
  // a) ノードとリンクの集計（employment_type→experience_level→company_size）
  // b) d3.sankey() でレイアウト
  // c) パスとノードを描画
  // TODO: 詳細実装
}

// 4) ヒストグラム（Context）
function drawHistogram(data) {
  const svg    = d3.select("#histogram");
  const W      = svg.node().clientWidth;
  const H      = svg.node().clientHeight;

  // 1) マージンと描画領域サイズ
  const margin = { top: 30, right: 20, bottom: 40, left: 50 };
  const width  = W - margin.left - margin.right;
  const height = H - margin.top - margin.bottom;

  // 2) SVG内のグループをずらす
  const g = svg.append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  // 3) データ抽出 & ビン分割
  const salaries = data.map(d => d.salary);
  const x = d3.scaleLinear()
    .domain(d3.extent(salaries))
    .nice()
    .range([0, width]);
  const bins = d3.bin()
    .domain(x.domain())
    .thresholds(30)(salaries);
  const y = d3.scaleLinear()
    .domain([0, d3.max(bins, d => d.length)])
    .nice()
    .range([height, 0]);

  // 4) 棒（rect）を描画
  g.selectAll("rect")
    .data(bins)
    .join("rect")
      .attr("x", d => x(d.x0) + 1)
      .attr("y", d => y(d.length))
      .attr("width", d => Math.max(0, x(d.x1) - x(d.x0) - 1))
      .attr("height", d => height - y(d.length))
      .attr("fill", "steelblue");

  // 5) 軸の描画
  g.append("g")
    .attr("transform", `translate(0,${height})`)
    .call(d3.axisBottom(x).ticks(6).tickFormat(d3.format("$.2s")));
  g.append("g")
    .call(d3.axisLeft(y));

  // 6) タイトルと軸ラベル
  // タイトル
  svg.append("text")
    .attr("x", W/2)
    .attr("y", margin.top/2)
    .attr("text-anchor", "middle")
    .style("font-size", "16px")
    .text("Salary Distribution");
  // X軸ラベル
  svg.append("text")
    .attr("x", margin.left + width/2)
    .attr("y", H - 6)
    .attr("text-anchor", "middle")
    .text("Salary (USD)");
  // Y軸ラベル
  svg.append("text")
    .attr("x", - (margin.top + height/2))
    .attr("y", 12)
    .attr("transform", "rotate(-90)")
    .attr("text-anchor", "middle")
    .text("Count");
}
